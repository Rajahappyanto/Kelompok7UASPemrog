    <footer>
        <p>&copy; 2024 - Kelompok7- Raja/Hapiansah/Ryam - TI.22.A.2 - Universitas Pelita Bangsa - Cikarang Selatan</p>
    </footer>
    </div>
</body>
</html>
